﻿using System;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World! This is from webjob");
        }
    }
}
